/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.part1;
import java.util.Scanner;
/**
 *
 * @author Student
 */
public class Part1 {

    private String username;
    private String password;
    private String cellPhone;
   
public String registerUser(
        String username,
        String password,
        String cellPhone) {

    if (!checkUserName(username)) {
        return "Please ensure that your username contains an underscore and is no more than 5 characters in length.";
    }

    if (!checkPasswordStrength(password)) {
        return "Please ensure that the password contains at least 8 characters, a capital letter, a number and a special character.";
    }

    if (!checkCellPhoneNumber(cellPhone)) {
        return "Cell phone number is incorrectly formatted or does not contain a code.";
    }

    this.username = username;
    this.password = password;
    this.cellPhone = cellPhone;

    return "User registered successfully.";
}

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("");
        
    }

    public boolean checkUserName(String username) {

    if (username.contains("_") && username.length() <= 5) {
        return true;
    } else {
        return false;
    }
}
   

public boolean checkPasswordComplexity(String password) {

    boolean capital = false;
    boolean number = false;
    boolean special = false;

    if (password.length() >= 8) {

        for (int i = 0; i < password.length(); i++) {

            char character = password.charAt(i);

            if (character >= 'A' && character <= 'Z') {
                capital = true;
            }

            if (character >= '0' && character <= '9') {
                number = true;
            }

            if (!((character >= 'A' && character <= 'Z')
                    && (character >= 'a' && character <= 'z')
                    &&(character >= '0' && character <= '9'))) {
                special = true;
            }
        }
    }

    if (capital && number && special) {
        return true;
    } else {
        return false;
    }
}

public String returnLoginStatus(boolean loginSuccessful) {

    if (loginSuccessful) {
        String firstName = null;
        String lastName = null;
        return "Welcome back " + firstName + lastName
                + " it is great to see you again.";
    } else {
        return "Username or password incorrect, please try again.";
    }
}

    private boolean checkPasswordStrength(String password) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private boolean checkCellPhoneNumber(String cellPhone) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

  
  

}
