/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
 import java.util.Scanner;
/**
 *
 * @author Student
 */
public class Part1Chat {
     private String username;
    private String password;
    private String cellPhone;
    private String firstName;
    private String lastName;

    public Part1Chat (String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
    }
     public boolean checkUserName(String username) {
//This wll check if the username contains an underscore and if the length is 
//equal or less than 5 letters long. if that is true, the program will continu
        if (username.contains("_") && username.length() <= 5) {
            return true;
        } else {
            return false;
        }
    }
      

    public boolean checkPasswordComplexity(String password) {

        boolean capital = false;
        boolean number = false;
        boolean special = false;

        if (password.length() >= 8) {

            for (int i = 0; i < password.length(); i++) {

                char character = password.charAt(i);

                if (character >= 'A' && character <= 'Z') {
                    capital = true;
                }

                if (character >= '0' && character <= '9') {
                    number = true;
                }

                if (!((character >= 'A' && character <= 'Z')
                        && (character >= 'a' && character <= 'z')
                        && (character >= '0' && character <= '9'))) {
                    special = true;
                }
              }
          }

        if (capital && number && special) {
            return true;
        } else {
            return false;
        }
    }

}