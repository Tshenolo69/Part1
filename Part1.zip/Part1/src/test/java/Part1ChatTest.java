/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import com.mycompany.part1.Part1;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Student
 */
public class Part1ChatTest {
  

public class LoginTest {
 
}
@Test // Checks if the username meets the requirements
public void checkUsername(){
    Part1 obj = new Part1();
    boolean result = obj.checkUserName("Kyl_1");
    assertEquals(true,result);
}
@Test// Checks if the username contains an underscore or not
public void checkUserUnderscore(){
    Part1 obj = new Part1();
    boolean result = obj.checkUserName("Kyle1");
    assertEquals(false, result);
}
@Test//Checks if the length of the username has 5 characters
public void checkUsernameLength(){
    Part1 obj = new Part1();
    boolean result = obj.checkUserName("abc_1");
    assertEquals(true, result);
}
@Test// checks if the users password is correct
public void checkPassComplexity(){
    Part1 obj = new Part1();
    boolean result = obj.checkPasswordComplexity("Ch&&sec@ke99");
    assertEquals(true,result);
} 
@Test// checks if the password is incorrect
public void checkPasscomplexity(){
    Part1 obj = new Part1();
    boolean result = obj.checkPasswordComplexity("password");
    assertEquals(false,result);
}
@Test//Checks if the password contains any special charaters
public void checkPassCharacters(){
    Part1 obj = new Part1();
    boolean result = obj.checkPasswordComplexity("Password123");
    assertEquals(false,result);
}
}
